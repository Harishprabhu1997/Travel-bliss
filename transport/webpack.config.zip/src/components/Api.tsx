export const primary_key = 'f71f436092f6426a989867d9ccac7e56';
export const app_id = "8268063a"
export const base_url ='https://api.tfl.gov.uk';
export const modes =['bus','tube','national-rail','dlr','overground','elizabeth-line','river-bus','tram','cable-car','coach']